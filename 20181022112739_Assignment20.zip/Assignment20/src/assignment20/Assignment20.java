package assignment20;

import java.util.Random;
import java.util.Scanner;

public class Assignment20 {

    public static void main(String[] args) {

        int i;
        int index = 0;
        int element;
        int number;
        int location = 0;

        Scanner keyboard = new Scanner(System.in);
        Random randomobj = new Random();

        System.out.println("How many elements?");
        element = keyboard.nextInt();
        int[] array1 = new int[element];
        System.out.println("Random numbers are:");

        for (i = 0; i < element; i++) {
            System.out.print(" " + (i + 1) + ":");
            array1[i] = randomobj.nextInt(800);
            System.out.println(" " + array1[i]);

        }
        System.out.print("Which number to search?");
        number = keyboard.nextInt();

        for (i = 0; i < element; i++) {
            if (number == array1[i]) {
                location = i + 1;
            }
        }
        if (location == 0) {
            System.out.println("Element not found");
        } else {
            System.out.println("Elementfound at index:" + location);
        }
        System.out.println("End of this assignment");
    }

}
